/**
 * 
 */
var request=require('request');
exports.calc=function(req,res){
	console.log("server ");
	var operation=req.param("operation");
	var number1=req.param("number1");
	var number2=req.param("number2");
	number1=parseInt(number1);
	number2=parseInt(number2);
	var result='';
	try{
		if(operation==="add")
			result=number1+number2;
		else if(operation==="sub")
			result=number1-number2;
		else if(operation==="mul")
			result=number1*number2;
		else if(operation==="div")
			result=number1/number2;
		
		res.json({result:result},{exception:''});
		//res.render('index',{result:result},{exception:''});
		
	}
	catch(err)
	{
		
		res.render('index',{result:result},{exception:err});
	}
};
exports.callapi=function(req,res){
	var operation=req.param("operation");
	var number1=req.param("number1");
	var number2=req.param("number2");
	number1=parseInt(number1);
	number2=parseInt(number2);
	var res_req='';
	request('http://localhost:3001/calc?oper='+operation+'&num1='+number1+'&num2='+number2, function (error, response, body) {
		  if (!error && response.statusCode == 200) {
		    console.log("using request method: " + body) // Show the HTML for the Google homepage.
		    res_req = body;
		    console.log('ouside log = ' + res_req);
		  }
	});
	
};