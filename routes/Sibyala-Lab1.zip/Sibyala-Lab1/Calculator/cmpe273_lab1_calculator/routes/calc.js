/**
 * 
 */
var request=require('request');
exports.calc=function(req,res){
	var operation=req.param("operation");
	var number1=req.param("number1");
	var number2=req.param("number2");
	number1=parseInt(number1);
	number2=parseInt(number2);
	var result='';
	try{
		if(operation==="add")
			result=number1+number2;
		else if(operation==="sub")
			result=number1-number2;
		else if(operation==="mul")
			result=number1*number2;
		else if(operation==="div")
			result=number1/number2;
		
		res.render('index',{result:result,exception:''});
		res.end();
		
	}
	catch(err)
	{
		
		res.render('index',{result:result,exception:'err'});
	}
};
exports.callapi=function(req,res){
	var operation=req.param("operation");
	var number1=req.param("number1");
	var number2=req.param("number2");
	number1=parseInt(number1);
	number2=parseInt(number2);
	var res_req='';
	console.log("hai");
	request('http://localhost:3000/calc?number1=12&number2=12&operation=add', function (error, response, body) {
		  if (!error && response.statusCode == 200) {
		    console.log("using request method: " + body) // Show the HTML for the Google homepage.
		    res_req = body;
		    console.log('ouside log = ' + res_req);
		  }
	});
	
};